package kadai.chap5;

import tool.Page;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns={"/kadai/chap5/mondai7"})
public class mondai7 extends HttpServlet{
    public void doPost(
        HttpServletRequest request, HttpServletResponse response
    )throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        request.setCharacterEncoding("UTF-8");
        String user = request.getParameter("user");
        int age = Integer.parseInt(request.getParameter("age"));

        Page.header(out);
        out.println("<p>こんにちは、" + user + "(" + age + ")さん!</p>");
        out.println("10年後は" + (age+10) + "歳ですね!"); 
        Page.footer(out);
    }
}
