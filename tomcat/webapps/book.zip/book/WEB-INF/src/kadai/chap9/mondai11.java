package kadai.chap9;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns={"/kadai/chap9/mondai11"})
public class mondai11 extends HttpServlet{

    public void doGet(
        HttpServletRequest request, HttpServletResponse response
    )throws ServletException, IOException{
        request.getRequestDispatcher("mondai11.jsp").forward(request, response);
    }
}