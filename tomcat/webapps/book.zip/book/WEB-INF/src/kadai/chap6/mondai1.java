package kadai.chap6;

import tool.Page;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns={"/kadai/chap6/mondai1"})
public class mondai1 extends HttpServlet{
    
    public void doGet(
        HttpServletRequest request, HttpServletResponse response
    )throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        request.setCharacterEncoding("UTF-8");
        String syuto=request.getParameter("syuto");

        Page.header(out);
        out.println("<p>こんにちは、" + syuto + "にお住まいなんですね。");
        Page.footer(out);
    }
}
