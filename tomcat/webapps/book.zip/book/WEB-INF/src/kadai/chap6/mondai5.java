package kadai.chap6;

import tool.Page;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet(urlPatterns={"/kadai/chap6/mondai5"})
public class mondai5 extends HttpServlet{
    
    public void doGet(
        HttpServletRequest request, HttpServletResponse response
    )throws ServletException, IOException{
        response.setContentType("text/html; charset=UTF-8");
        PrintWriter out = response.getWriter();

        request.setCharacterEncoding("UTF-8");
        String user = request.getParameter("user");
        int age = Integer.parseInt(request.getParameter("age"));
        String syuto=request.getParameter("syuto");
        String[] transport=request.getParameterValues("transport");
        String review=request.getParameter("review");

        Page.header(out);
        out.println("<p>ご入力頂いた内容の確認です。よろしければ、下の登録ボタンを押してください。</p>");
        out.println("<dl>");
        out.println("<dt>お名前:</dt><dd>    " + user + "</dd>");
        out.println("<dt>ご年齢:</dt><dd>    " + age + "</dd>");
        out.println("<dt>お住まい:</dt><dd>    " + syuto + "</dd>");
        out.println("<dt>利用交通機関:</dt><dd>    ");
        for(String item : transport){
            out.print(item);
        }
        out.println("</dd>");
        out.println("<dt>お問い合わせ内容:</dt><dd>    " + review + "</dd>");
        out.println("<input type='submit' value='登録'>");
        out.println("</dl>");
        Page.footer(out);
    }
}
